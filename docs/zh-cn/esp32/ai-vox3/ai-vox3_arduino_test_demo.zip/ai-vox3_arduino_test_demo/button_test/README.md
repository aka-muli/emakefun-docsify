# 按键测试 (button_test)

## 功能说明

测试开发板上的两个用户按键（按键 A 和按键 B），支持检测**单击**、**双击**和**长按**三种操作，结果通过串口输出。

## 依赖库

| 库名 | 安装方式 |
|------|---------|
| OneButton | Arduino IDE → 工具 → 管理库 → 搜索 `OneButton` 安装 |

## 使用方法

1. 安装依赖库 `OneButton`
2. 编译并上传程序
3. 打开串口监视器，波特率设为 **115200**
4. 操作按键 A 或按键 B

## 预期结果

串口会先输出 `Button Test Start`，然后根据操作输出：

| 操作 | 串口输出 |
|------|---------|
| 单击按键 A | `ButtonA: Click` |
| 双击按键 A | `ButtonA: Double Click` |
| 长按按键 A | `ButtonA: Long Press` |
| 单击按键 B | `ButtonB: Click` |
| 双击按键 B | `ButtonB: Double Click` |
| 长按按键 B | `ButtonB: Long Press` |

## 硬件说明

| 按键 | 引脚 |
|------|------|
| 按键 A | IO46 |
| 按键 B | IO45 |
