#include <OneButton.h>

#define BUTTONA_PIN 46
#define BUTTONB_PIN 45

OneButton buttonA(BUTTONA_PIN, true, true);
OneButton buttonB(BUTTONB_PIN, true, true);

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("Button Test Start");

  buttonA.attachClick([]() { Serial.println("ButtonA: Click"); });
  buttonA.attachDoubleClick([]() { Serial.println("ButtonA: Double Click"); });
  buttonA.attachLongPressStart([]() { Serial.println("ButtonA: Long Press"); });

  buttonB.attachClick([]() { Serial.println("ButtonB: Click"); });
  buttonB.attachDoubleClick([]() { Serial.println("ButtonB: Double Click"); });
  buttonB.attachLongPressStart([]() { Serial.println("ButtonB: Long Press"); });
}

void loop() {
  buttonA.tick();
  buttonB.tick();
  delay(10);
}
