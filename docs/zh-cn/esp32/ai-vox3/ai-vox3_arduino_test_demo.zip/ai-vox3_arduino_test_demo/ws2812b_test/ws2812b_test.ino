#include <Adafruit_NeoPixel.h>

#define PIN        41
#define NUM_LEDS   1
#define BRIGHTNESS_STEP 5
#define BRIGHTNESS_DELAY 15

Adafruit_NeoPixel strip(NUM_LEDS, PIN, NEO_GRB + NEO_KHZ800);

void setup() {
  Serial.begin(115200);
  strip.begin();
  strip.setBrightness(50);
  strip.show();

  for (int i = 0; i < 3; i++) {
    strip.setPixelColor(0, strip.Color(255, 255, 255));
    strip.show();
    delay(200);
    strip.clear();
    strip.show();
    delay(200);
  }
}

void loop() {
  Serial.println("=== Color Test ===");
  colorTest();

  Serial.println("=== Breathing ===");
  breathing();
}

void colorTest() {
  uint32_t colors[] = {
    strip.Color(255, 0, 0),
    strip.Color(0, 255, 0),
    strip.Color(0, 0, 255),
    strip.Color(255, 255, 255)
  };
  const char* names[] = {"RED", "GREEN", "BLUE", "WHITE"};

  for (int i = 0; i < 4; i++) {
    Serial.print("  ");
    Serial.println(names[i]);
    strip.setPixelColor(0, colors[i]);
    strip.show();
    delay(1000);
  }
  strip.clear();
  strip.show();
  delay(500);
}

void breathing() {
  for (int round = 0; round < 3; round++) {
    for (int b = 0; b <= 255; b += BRIGHTNESS_STEP) {
      strip.setBrightness(b);
      strip.setPixelColor(0, strip.Color(255, 255, 255));
      strip.show();
      delay(BRIGHTNESS_DELAY);
    }
    for (int b = 255; b >= 0; b -= BRIGHTNESS_STEP) {
      strip.setBrightness(b);
      strip.setPixelColor(0, strip.Color(255, 255, 255));
      strip.show();
      delay(BRIGHTNESS_DELAY);
    }
  }
  strip.setBrightness(50);
  strip.clear();
  strip.show();
  delay(500);
}
